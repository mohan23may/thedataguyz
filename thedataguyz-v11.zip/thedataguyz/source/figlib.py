"""Shared figure chrome. Palette validated with the dataviz skill's validator:
   ordinal blue ramp (--ordinal light: ALL PASS) and the #1D4ED8/#9A4A08 pair (ALL PASS)."""
L1, L2, L3, L4 = '#86b6ef', '#3987e5', '#256abf', '#104281'
BLUE, ACCENT, TEAL = '#1D4ED8', '#9A4A08', '#0E6B7A'
INK, BODY, MUTE, LINE, TRACK = '#141B2E', '#4C5470', '#6B7391', '#CBD5E6', '#EDF1F8'
FONT = "font-family: 'Inter', system-ui, sans-serif"

def figure(kicker, title, intro, svg, caption, sowhat, note='', accent=BLUE, bg='#FFFFFF', anchor=''):
    aid = f' id="{anchor}"' if anchor else ''
    notehtml = f'\n        <p style="margin: 14px 0 0; font-size: 12.5px; line-height: 1.6; color: {MUTE}">{note}</p>' if note else ''
    return f'''  <!-- FIGURE: {kicker} -->
  <section{aid} style="background: {bg}; padding: 80px 32px; border-top: 1px solid #E2E8F3">
    <div style="max-width: 1280px; margin: 0 auto">
      <div style="border-top: 3px solid {accent}; padding-top: 24px">
        <p style="margin: 0; font-family: 'JetBrains Mono', monospace; font-weight: 600; font-size: 11.5px; letter-spacing: 0.14em; color: {accent}">{kicker}</p>
        <h2 style="margin: 12px 0 0; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 700; font-size: clamp(23px, 2.5vw, 32px); line-height: 1.14; letter-spacing: -0.025em; max-width: 32ch">{title}</h2>
        <p style="margin: 14px 0 0; font-size: 16.5px; line-height: 1.65; color: {BODY}; max-width: 80ch">{intro}</p>
        <figure style="margin: 34px 0 0">
{svg}
          <figcaption style="margin: 18px 0 0; font-size: 13px; line-height: 1.6; color: {MUTE}">{caption}</figcaption>
        </figure>
        <div style="margin-top: 22px; background: {'#EAF1FE' if accent==BLUE else ('#FBEFE4' if accent==ACCENT else '#E2F4F7')}; border-radius: 8px; padding: 20px 24px">
          <p style="margin: 0; font-size: 15.5px; line-height: 1.6; color: {'#1A2E5C' if accent==BLUE else ('#7A3A06' if accent==ACCENT else '#0B4A55')}"><strong style="color: #0E1730">So what:</strong> {sowhat}</p>
        </div>{notehtml}
      </div>
    </div>
  </section>

'''

def svg_open(vb, label, extra=''):
    pr = str(vb).split()
    vb = ' '.join((['0','0'] + pr)[-4:])
    return (f'          <svg viewBox="{vb}" role="img" aria-label="{label}" '
            f'style="width: 100%; max-width: 100%; height: auto; {FONT}{extra}">')

ARROWS = f'''
            <defs>
              <marker id="fa" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1 L9 5 L0 9 z" fill="{BLUE}"></path></marker>
              <marker id="fb" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1 L9 5 L0 9 z" fill="{ACCENT}"></path></marker>
              <marker id="fc" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1 L9 5 L0 9 z" fill="{TEAL}"></path></marker>
            </defs>'''

def insert(path, anchor, html, height=None):
    import pathlib, re
    p = pathlib.Path(path); t = p.read_text(encoding='utf-8')
    assert anchor in t, (path, anchor)
    t = t.replace(anchor, html + anchor, 1)
    if height:
        t = re.sub(r'"\$preview":\{"width":1400,"height":\d+\}', f'"$preview":{{"width":1400,"height":{height}}}', t, count=1)
    p.write_text(t, encoding='utf-8')
    return len(t)


# ---------------- reusable chart builders (validated palette only) ----------------
RAMP = [L1, L2, L3, L4] = ['#86b6ef', '#3987e5', '#256abf', '#104281']

def wrap(s, n):
    ws, ln, out = s.split(), '', []
    for w in ws:
        if len(ln + ' ' + w) > n: out.append(ln); ln = w
        else: ln = (ln + ' ' + w).strip()
    out.append(ln); return out

def heat_svg(rows, cols, levels, title_note, foot, vw=1160, labw=300, cellh=38, accent=None):
    """rows: [(label, sublabel, [levelkeys])]  levels: {key:(fill,text,fg)}"""
    acc = accent or BLUE
    gap, n = 6, len(cols)
    cw = (vw - labw - gap*(n-1)) / n
    out, y = [], 54
    for j, c in enumerate(cols):
        x = labw + j*(cw+gap)
        out.append(f'<text x="{x}" y="42" font-size="10" font-weight="600" letter-spacing="1" fill="{MUTE}">{c}</text>')
    for lab, sub, lv in rows:
        out.append(f'<text x="0" y="{y+(cellh/2)+1}" font-size="13.6" font-weight="600" fill="{INK}">{lab}</text>')
        if sub:
            out.append(f'<text x="0" y="{y+(cellh/2)+17}" font-size="10.8" fill="{acc}">{sub}</text>')
        for j, k in enumerate(lv):
            fill, txt, fg = levels[k]
            x = labw + j*(cw+gap)
            out.append(f'<rect x="{x}" y="{y}" width="{cw}" height="{cellh}" rx="5" fill="{fill}"></rect>')
            out.append(f'<text x="{x+cw/2}" y="{y+cellh/2+4.4}" font-size="12.2" font-weight="600" fill="{fg}" text-anchor="middle">{txt}</text>')
        y += cellh + (26 if sub else 12)
    legend = []
    lx = 0
    for k, (fill, txt, fg) in levels.items():
        if txt in ('—', ''): continue
        legend.append(f'<rect x="{lx}" y="6" width="12" height="12" rx="3" fill="{fill}"></rect>')
        legend.append(f'<text x="{lx+19}" y="16" font-size="12" fill="{BODY}">{txt}</text>')
        lx += 26 + len(txt)*7.1
    h = y + 48
    return (svg_open(f'{vw} {h}', title_note) + '\n            ' + ''.join(legend) + ''.join(out) +
            f'<text x="0" y="{h-14}" font-size="11.4" fill="{BODY}">{foot}</text>\n          </svg>')

def steps_svg(steps, label, foot, vw=1160, bh=132, accent=None, dark_last=True):
    """steps: [(kicker, title, body)] rendered as a left-to-right arrowed flow"""
    acc = accent or BLUE
    n = len(steps); gap = 30
    bw = (vw - gap*(n-1)) / n
    out = []
    for i, (k, t_, s_) in enumerate(steps):
        x = i*(bw+gap); last = dark_last and i == n-1
        fill = '#0E1730' if last else '#FFFFFF'
        out.append(f'<rect x="{x}" y="44" width="{bw}" height="{bh}" rx="7" fill="{fill}" stroke="{"#0E1730" if last else LINE}" stroke-width="1.4"></rect>')
        out.append(f'<text x="{x+16}" y="70" font-size="10" font-weight="600" letter-spacing="1.1" fill="{"#8FB2F8" if last else acc}">{k}</text>')
        out.append(f'<text x="{x+16}" y="94" font-size="14.6" font-weight="700" fill="{"#FFFFFF" if last else INK}">{t_}</text>')
        for q, l in enumerate(wrap(s_, int((bw-36)/5.7))[:4]):
            out.append(f'<text x="{x+16}" y="{116+q*15}" font-size="11.2" fill="{"#BCC5DA" if last else BODY}">{l}</text>')
        if i < n-1:
            out.append(f'<line x1="{x+bw+3}" y1="{44+bh/2}" x2="{x+bw+gap-7}" y2="{44+bh/2}" stroke="{acc}" stroke-width="1.6" marker-end="url(#fa)"></line>')
    h = 44 + bh + 46
    return (svg_open(f'{vw} {h}', label) + f'\n            <text x="0" y="16" font-size="11" font-weight="600" letter-spacing="1.4" fill="{MUTE}">{foot.upper()}</text>'
            + ''.join(out) + ARROWS + '\n          </svg>')

def ranked_svg(items, label, axis_max, unit, foot, vw=1160, labw=300, rowh=44):
    """items: [(label, value, note)] single-series ranked bars"""
    out, y, barw = [], 44, vw - labw - 230
    for i, (lab, v, note) in enumerate(items):
        w = max(6, int(barw * v / axis_max))
        fill = RAMP[3] if i == 0 else RAMP[2] if i < 3 else RAMP[1]
        out.append(f'<text x="0" y="{y+18}" font-size="13.6" font-weight="600" fill="{INK}">{lab}</text>')
        out.append(f'<rect x="{labw}" y="{y}" width="{barw}" height="26" rx="4" fill="{TRACK}"></rect>')
        out.append(f'<rect x="{labw}" y="{y}" width="{w}" height="26" rx="4" fill="{fill}"></rect>')
        out.append(f'<text x="{labw+w+12}" y="{y+18}" font-size="13.4" font-weight="700" fill="{INK}">{v}</text>')
        out.append(f'<text x="{labw+w+38}" y="{y+18}" font-size="11.2" fill="{MUTE}">{note}</text>')
        y += rowh
    h = y + 52
    return (svg_open(f'{vw} {h}', label) + f'\n            <text x="0" y="16" font-size="11" font-weight="600" letter-spacing="1.4" fill="{MUTE}">{foot.upper()}</text>'
            + ''.join(out) + f'<line x1="{labw}" y1="{y-12}" x2="{labw+barw}" y2="{y-12}" stroke="{LINE}" stroke-width="1"></line>'
            + f'<text x="{labw}" y="{y+8}" font-size="11" fill="{MUTE}">0</text>'
            + f'<text x="{labw+barw}" y="{y+8}" font-size="11" fill="{MUTE}" text-anchor="end">{axis_max} {unit}</text>\n          </svg>')
