#!/usr/bin/env python3
"""Convert the Design-canvas .dc.html artboards into a plain static website."""
import re, pathlib, shutil, sys

BASE = pathlib.Path('/tmp/claude-0/-home-claude/79d816d8-28ac-551e-a505-1a1196ca7dd6/scratchpad')
root, out, imgs = BASE / 'tdg-site/project', BASE / 'tdg-web', BASE / 'imgs'
BLOB = '/_blob/98062f3b7d159a93514746e9c9084b75'
STEMS = ['Main', 'Services', 'Offers', 'Noviq', 'Industries', 'Accountants', 'UseCases', 'CaseStudies', 'About']
page = lambda s: 'index.html' if s == 'Main' else s + '.html'

if out.exists():
    shutil.rmtree(out)
out.mkdir(parents=True)

for stem in STEMS:
    t = (root / (stem + '.dc.html')).read_text(encoding='utf-8')
    title = re.search(r'<title>(.*?)</title>', t, re.S).group(1).strip()
    helmet = re.search(r'<helmet>(.*?)</helmet>', t, re.S).group(1).strip()
    body = t.split('</helmet>', 1)[1].split('</x-dc>')[0].strip()
    doc = ('<!doctype html>\n<html lang="en-AU">\n<head>\n<meta charset="utf-8">\n'
           '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
           '<meta name="theme-color" content="#0E1730">\n'
           f'<title>{title}</title>\n{helmet}\n</head>\n<body>\n{body}\n</body>\n</html>\n')
    for s in STEMS:
        doc = doc.replace(f'"{s}.dc.html', f'"{page(s)}').replace(f"'{s}.dc.html'", f"'{page(s)}'")
    (out / page(stem)).write_text(doc.replace(BLOB, 'founder.jpg'), encoding='utf-8')

shutil.copy(imgs / 'founder.jpg', out / 'founder.jpg')

# ---- hero marquee -> vanilla JS ----
src = (root / 'Main.dc.html').read_text(encoding='utf-8')
slides = re.search(r'slideData\(\) \{\s*return \[(.*?)\n    \];', src, re.S).group(1)
for s in STEMS:
    slides = slides.replace(f"'{s}.dc.html", f"'{page(s)}")

p = out / 'index.html'
d = p.read_text(encoding='utf-8')
d = d.replace('{{ slide.tag }}', '<span id="mq-tag"></span>')
d = d.replace('white-space: pre-line">{{ slide.headline }}</h1>', 'white-space: pre-line" id="mq-headline"></h1>')
d = d.replace('max-width: 62ch">{{ slide.body }}</p>', 'max-width: 62ch" id="mq-body"></p>')
d = d.replace('href="{{ slide.href }}"', 'href="Services.html" id="mq-cta"')
d = d.replace('{{ slide.cta }}', '<span id="mq-ctatext"></span>')
dots = re.search(r'<div role="group" aria-label="Choose a featured story".*?</div>', d, re.S).group(0)
d = d.replace(dots, '<div id="mq-dots" role="group" aria-label="Choose a featured story" '
                    'style="display: flex; flex-wrap: wrap; gap: 10px"></div>')
d = d.replace('{{ position }}', '<span id="mq-pos"></span>')
d = d.replace('onClick="{{ prev }}"', 'id="mq-prev"').replace('onClick="{{ next }}"', 'id="mq-next"')

MQ = r"""
<script>
(function(){var SLIDES=[__S__];var i=0,timer=null;
var g=function(id){return document.getElementById(id)};
var tag=g('mq-tag'),hl=g('mq-headline'),bd=g('mq-body'),cta=g('mq-cta'),ct=g('mq-ctatext'),dots=g('mq-dots'),pos=g('mq-pos');
function pad(n){return (n<10?'0':'')+n}
function paint(){var s=SLIDES[i];tag.textContent=s.tag;hl.textContent=s.headline;bd.textContent=s.body;ct.textContent=s.cta;cta.setAttribute('href',s.href);
pos.textContent=pad(i+1)+' / '+pad(SLIDES.length);dots.innerHTML='';
SLIDES.forEach(function(sl,n){var b=document.createElement('button');b.type='button';b.setAttribute('aria-label',sl.label);b.setAttribute('aria-current',String(n===i));
b.setAttribute('style','width:44px;height:6px;border-radius:999px;border:none;padding:0;cursor:pointer;background:'+(n===i?'#1D4ED8':'#2A3A63')+';');
b.addEventListener('click',function(){go(n)});dots.appendChild(b)})}
function go(n){if(timer){clearInterval(timer);timer=null}i=(n+SLIDES.length)%SLIDES.length;paint()}
g('mq-prev').addEventListener('click',function(){go(i-1)});g('mq-next').addEventListener('click',function(){go(i+1)});
paint();timer=setInterval(function(){i=(i+1)%SLIDES.length;paint()},7000)})();
</script>
"""
p.write_text(d.replace('</body>', MQ.replace('__S__', slides) + '</body>'), encoding='utf-8')

# ---- use-case filter -> vanilla JS ----
uc = (root / 'UseCases.dc.html').read_text(encoding='utf-8')
data = re.search(r'useCases\(\) \{\s*return \[(.*?)\n    \];', uc, re.S).group(1)
doms = re.search(r'domainList\(\) \{\s*return \[(.*?)\n    \];', uc, re.S).group(1)
q = out / 'UseCases.html'
d = q.read_text(encoding='utf-8')
fb = re.search(r'<div role="group" aria-label="Filter use cases by domain".*?</div>\s*</div>', d, re.S).group(0)
d = d.replace(fb, '<div id="tdg-filters" role="group" aria-label="Filter use cases by domain" '
                  'style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px"></div>\n          </div>')
d = d.replace('<strong style="color: #141B2E">{{ count }}</strong>',
              '<strong id="tdg-count" style="color: #141B2E">36</strong>')
lb = re.search(r'<div style="margin-top: 32px; display: flex; flex-direction: column; gap: 12px">.*?</sc-for>\s*</div>', d, re.S).group(0)
d = d.replace(lb, '<div id="tdg-list" style="margin-top: 32px; display: flex; flex-direction: column; gap: 12px"></div>')

UCJS = r"""
<script>
(function(){var DOMAINS=[__D__];var CASES=[__C__];var active='all';
var base='display:inline-flex;align-items:center;min-height:44px;padding:0 18px;border-radius:999px;font-size:14px;font-weight:600;cursor:pointer;';
var MONO="font-family: 'JetBrains Mono', monospace;";
var filters=document.getElementById('tdg-filters'),list=document.getElementById('tdg-list'),countEl=document.getElementById('tdg-count');
function esc(s){var e=document.createElement('div');e.textContent=s;return e.innerHTML}
function rf(){filters.innerHTML='';DOMAINS.forEach(function(dm){var b=document.createElement('button');b.type='button';b.textContent=dm.label;
b.setAttribute('aria-pressed',String(dm.id===active));
b.setAttribute('style',base+(dm.id===active?'background:#1D4ED8;color:#FFFFFF;border:1px solid #1D4ED8;':'background:#FFFFFF;color:#3B4360;border:1px solid #CBD5E6;'));
b.addEventListener('click',function(){active=dm.id;render()});filters.appendChild(b)})}
function col(l,v,x){return '<div><h4 style="margin:0;font-size:11px;'+MONO+'font-weight:600;letter-spacing:0.12em;color:#8E99B6">'+l+'</h4><p style="margin:8px 0 0;font-size:14.8px;line-height:1.6;'+x+'">'+esc(v)+'</p></div>'}
function render(){rf();var items=active==='all'?CASES:CASES.filter(function(u){return u.domain===active});countEl.textContent=items.length;
list.innerHTML=items.map(function(u){return '<article style="border:1px solid #E2E8F3;border-radius:8px;padding:28px 26px;background:#FFFFFF;display:grid;grid-template-columns:repeat(auto-fit,minmax(min(250px,100%),1fr));gap:20px 32px;align-items:start">'
+'<div><div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">'
+'<span style="'+MONO+'font-size:10.5px;font-weight:600;letter-spacing:0.1em;color:#6B7391;background:#EDF1F8;padding:6px 10px;border-radius:999px">'+esc(u.domainLabel)+'</span>'
+(u.isPoc?'<span style="'+MONO+'font-size:10.5px;font-weight:600;letter-spacing:0.1em;color:#FFFFFF;background:#1D4ED8;padding:6px 10px;border-radius:999px">POC</span>':'')
+'</div><h3 style="margin:12px 0 0;font-size:18px;line-height:1.3">'+esc(u.name)+'</h3></div>'
+col('THE QUESTION IT ANSWERS',u.question,'color:#4C5470')+col('DATA &amp; PLATFORMS',u.data,'color:#4C5470')
+col('PROOF PATTERN',u.proof,'color:#3B4360;font-weight:500')+'</article>'}).join('')}
render()})();
</script>
"""
q.write_text(d.replace('</body>', UCJS.replace('__D__', doms).replace('__C__', data) + '</body>'), encoding='utf-8')

(out / '.nojekyll').write_text('', encoding='utf-8')
for extra in ('README.md', 'PUSH.md'):
    f = BASE / 'docs' / extra
    if f.exists():
        shutil.copy(f, out / extra)

bad = {f.name: len(re.findall(r'\.dc\.html|\{\{|sc-for|sc-if', f.read_text(encoding='utf-8')))
       for f in out.glob('*.html')}
print('built:', sorted(f.name for f in out.iterdir()))
print('template leftovers:', {k: v for k, v in bad.items() if v} or 'none')
sys.exit(1 if any(bad.values()) else 0)
