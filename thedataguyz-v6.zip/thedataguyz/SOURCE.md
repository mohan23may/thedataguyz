# The Data Guyz — website source

Two things live in this folder.

```
thedataguyz/
├─ index.html, Services.html, …      ← the built static site (deploy this)
├─ founder.jpg, .nojekyll
├─ README.md, PUSH.md
└─ source/
   ├─ build.py                        ← converter: canvas source → static site
   └─ project/
      ├─ canvas.json                  ← board layout / index
      └─ *.dc.html                    ← 9 page sources
```

## What the source files are

`project/*.dc.html` are Design-canvas artboards. Each is a normal HTML page wrapped in
`<x-dc>` with a `<helmet>` block for fonts and base CSS, plus a small `<script type="text/x-dc">`
block at the end holding preview dimensions. Two pages carry interactive state in that script:

- `Main.dc.html` — the rotating marquee hero (5 slides, 7s autoplay)
- `UseCases.dc.html` — the domain filter over the use-case library

`canvas.json` is the index: board positions, sizes, titles and reading order on the canvas.

## The 9 pages

| Source | Built as | What it is |
|---|---|---|
| `Main.dc.html` | `index.html` | Home — marquee hero, journey, four pillars, exhibits |
| `Services.dc.html` | `Services.html` | Capabilities — 4 pillars, exhibits 01–07, delivery |
| `Offers.dc.html` | `Offers.html` | Offer catalogue — 16 packages in 5 groups, partner models |
| `Noviq.dc.html` | `Noviq.html` | Noviq / Noviq Shift product and delivery IP |
| `Industries.dc.html` | `Industries.html` | Industries served |
| `Accountants.dc.html` | `Accountants.html` | AI for accountants and finance teams |
| `UseCases.dc.html` | `UseCases.html` | Filterable use-case library |
| `CaseStudies.dc.html` | `CaseStudies.html` | Delivered engagements — the single home for proof |
| `About.dc.html` | `About.html` | About and contact |

Platform modernisation and AI agents are not separate pages. They are folded into
Capabilities as exhibits 01–02 (under Cloud Strategy) and 03–05 (under AI Adoption).

## Rebuilding

`build.py` strips the canvas wrapper, lifts `<helmet>` into `<head>`, rewrites every
`X.dc.html` link to `X.html` (and `Main.dc.html` → `index.html`), swaps the founder
image reference for the local `founder.jpg`, and re-implements the marquee and the
use-case filter as plain vanilla JS. It exits non-zero if any template placeholder
survives into the output.

It needs Python 3 only — no packages.

```
python3 build.py
```

Edit the paths at the top of `build.py` (`BASE`) to point at wherever you put this folder.

## Editing

Two ways, and they do not sync automatically:

1. **In the canvas artifact** — visual editing, then re-export the `project/` files and
   re-run `build.py`.
2. **In these files directly** — edit the `.dc.html` source, re-run `build.py`, deploy
   the output. The built `.html` files are generated; don't hand-edit them or the next
   build overwrites your changes.

## One home per idea

The site is deliberately de-duplicated. If you add content, keep to these rules:

- **Package and pricing detail** lives only on Offers.
- **Partnership models** live only on Offers (`#partners`).
- **Case-study narrative** lives only on Case studies. Everywhere else carries a
  one-line claim and a link. The four numbered exhibits on the home page are the
  deliberate exception.
- **Capability depth** lives only on Capabilities, as numbered exhibits.

## Exhibit convention

Each exhibit on Capabilities carries, in order: an `EXHIBIT NN` label and a kicker,
a headline, a 30–40 word intro, the visual, a **So what:** takeaway in a tinted box,
and a source footnote. Keep that order when adding one, and renumber the rest.

## Conventions worth keeping

- Inline styles throughout — that is what the canvas properties panel edits.
- No root-level pixel widths; `max-width` containers and
  `repeat(auto-fit, minmax(min(Npx, 100%), 1fr))` grids so pages stay fluid.
- Fonts: Plus Jakarta Sans (display), Inter (body), JetBrains Mono (micro-labels).
- Palette: navy `#0E1730` ground, primary blue `#1D4ED8`, page ground `#F6F8FC`,
  cyan `#5FD4E4` on dark. Pillar accents: blue `#1D4ED8`, teal `#0E6B7A`, amber `#9A4A08`.
- 8px card radius, 6px flow boxes, 999px pills.
- Diagrams are built from separate flex/grid elements joined by small chevron SVGs,
  never one large `<svg>` — so they reflow and stay editable.

## Deploying

See `PUSH.md` for the GitHub Pages steps. `.nojekyll` is required so GitHub serves the
files as-is.
